//Deviceタブ
#include <LiquidCrystal.h>
LiquidCrystal lcd(5, 6, 7, 8, 9, 10, 11);
const int SW1Pin = 2;
const int SW2Pin = 4;
const int LEDPin = 13;
const int SPKPin = 3;

void setupDevice(){}         //初期設定用関数
void displayString(String str1, String str2){}  //LCDに文字列を表示
boolean SW1IsPressed(){}    //SW1を押したか
boolean SW2IsPressed(){}    //SW2を押したか
void startBuzzer(){}        //ブザーを鳴らす
void stopBuzzer(){}         //ブザーを止める
void lightOn(){}            //LEDを点灯する
void lightOff(){}           //LEDを消灯する
