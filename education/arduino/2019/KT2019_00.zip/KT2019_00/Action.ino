//Actionタブ
void addOneMinute() {}  //設定時間を１分増加する
void startTimer() {}    //カウントダウンを開始する
void stopTimer() {}     //カウントダウンを停止する
void startAlarm() {}    //アラームを鳴らす
void stopAlarm() {}     //アラームを止める
void displayTimer(long ms) {} //時間を表示する
