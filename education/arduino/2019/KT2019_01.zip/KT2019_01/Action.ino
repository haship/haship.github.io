//Actionタブ
void addOneMinute(){}  //設定時間を１分増加する
void startTimer(){} //カウントダウンを開始する
void stopTimer(){}  //カウントダウンを停止する
void startAlarm(){} //アラームを鳴らす
void stopAlarm(){}  //アラームを止める

void displayTimer(long ms){  //時間を表示する
  int minute = int((ms/1000L)/60L);   //分を求める
  int second = int((ms/1000L)%60L);   //秒を求める
  int msec   = int(ms % 1000L);       //ミリ秒を求める

  String str1 = "";
  //分が1桁の場合
  if(minute >= 0 && minute < 10){
    //10の位に0を追加
    str1 += String("0");
  }
  //分を文字列str1に追加する
  str1 += String(minute);
  //分と秒の間に:を入れる
  str1 += String(":");
  //秒が1桁の場合
  if(second >=0 && second < 10){
    //10の位に0を追加
    str1 += String("0");
  }
  //秒を文字列str1に追加する
  str1 += String(second);
  //秒とミリ秒の間に .を追加
  str1 += String(".");
  //ミリ秒が2桁以下の場合
  if(msec >= 0 && msec < 100){
    //100の位に0を追加
    str1 += String("0");
  }
  //ミリ秒が1桁以下の場合
  if(msec >=0 && msec < 10){
    //10の位に0を追加
    str1 += String("0");
  }
  //ミリ秒を文字列str1に追加する
  str1 += String(msec);

  //時間を1行目に表示、空白2行目に表示
  displayString(str1, "");
}
