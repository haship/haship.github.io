long time;

void setup() {
  setupDevice();
  time = 0L;
}

void loop() {
  displayTimer(time);
  delay(500);
}
