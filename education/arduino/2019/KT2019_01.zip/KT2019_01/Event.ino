//Eventタブ
boolean MinuteButtonIsPressed(){}     //分ボタンを押したか
boolean StartStopButtonIsPressed(){}  //StartStopボタンを押したか
boolean TimeIsUp(){}                  //計測時間が0になったか
