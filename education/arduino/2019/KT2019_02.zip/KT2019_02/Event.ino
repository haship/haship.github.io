//Eventタブ
boolean MinuteButtonIsPressed(){      //分ボタンを押したか
  static boolean val_old = false;     //1回前の測定値を入れる変数
  boolean val = SWIsPressed(SW2Pin);  //現在の測定値
  boolean ret = false;                //戻り値を入れる変数
  
  if(val_old == true && val == false){
    ret = true;
  } else {
    ret = false;
  }
  val_old = val;  //測定値更新
  return ret;
}

boolean StartStopButtonIsPressed(){  //StartStopボタンを押したか
  static boolean val_old = false;     //1回前の測定値を入れる変数
  boolean val = SWIsPressed(SW1Pin);  //現在の測定値
  boolean ret = false;                //戻り値を入れる変数
  
  if(val_old == true && val == false){
    ret = true;
  } else {
    ret = false;
  }
  val_old = val;  //測定値更新
  return ret;
}

boolean TimeIsUp(){                  //計測時間が0になったか
  
}

enum Event receiveEvent(){
}
