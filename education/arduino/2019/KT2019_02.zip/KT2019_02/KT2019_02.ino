#include "config.h"

long time;        //設定時間
long startTime;   //カウントダウン開始時間
long remainTime;  //残り時間

void setup() {
  setupDevice();
  time = 0L;
  startTime = 0L;
  remainTime = 0L;
  state = STATE_INIT;   //状態変数を初期状態に設定する
  event = EVENT_NONE;   //イベント変数を"発生していない"に設定する
}

void loop() {

  if(MinuteButtonIsPressed()){
    addOneMinute();
  } else if(StartStopButtonIsPressed()){
    time = 0L;
  }
  
  displayTimer(time, state);
  delay(100);

}
