//Stateタブ
State handleEvent(State s, Event e){}
