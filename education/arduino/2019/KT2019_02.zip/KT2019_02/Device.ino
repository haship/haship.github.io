//Deviceタブ
#include <LiquidCrystal.h>
LiquidCrystal lcd(5, 6, 7, 8, 9, 10, 11);
const int SW1Pin = 2;
const int SW2Pin = 4;
const int LEDPin = 13;
const int SPKPin = 3;

void setupDevice(){         //初期設定用関数
  pinMode(SW1Pin, INPUT);   //SW1Pinを入力設定
  pinMode(SW2Pin, INPUT);   //SW2Pinを入力設定
  pinMode(LEDPin, OUTPUT);  //LEDPinを出力設定
  lcd.begin(16, 2);         //LCDの設定
  lcd.clear();              //画面消去
  Serial.begin(9600);       //シリアルモニタ開始
}
void displayString(String str1, String str2){  //LCDに文字列を表示
  lcd.clear();          //画面消去
  lcd.setCursor(0, 0);  //上段左端に移動
  lcd.print(str1);      //文字列str1を表示
  lcd.setCursor(0, 1);  //下段左端に移動
  lcd.print(str2);      //文字列str2を表示
}
boolean SWIsPressed(int pin){
  if(digitalRead(pin) == HIGH){
    return true;
  } else {
    return false;
  }
}

void startBuzzer(){    //ブザーを鳴らす
  tone(SPKPin, 880);
}

void stopBuzzer(){   //ブザーを止める
  noTone(SPKPin);
}

void lightOn(){      //LEDを点灯する
  digitalWrite(LEDPin, HIGH);
}

void lightOff(){   //LEDを消灯する
  digitalWrite(LEDPin, LOW);
}
