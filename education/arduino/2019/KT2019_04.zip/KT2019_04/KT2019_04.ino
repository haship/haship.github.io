#include "config.h"

long time;        //長整数型  設定時間
long startTime;   //長整数型  カウントダウン開始時間
long remainTime;  //長整数型  残り時間

void setup() {
  setupDevice();        //デバイスの初期設定を行う
  time = 0L;            //設定時間を初期化する
  startTime = 0L;       //カウントダウン開始時間を初期化する
  remainTime = 0L;      //残り時間を初期化する
  state = STATE_INIT;   //状態変数を初期状態に設定する
  event = EVENT_NONE;   //イベント変数を"発生していない"に設定する
}

void loop() {
  //現在発生しているイベントを返す
  event = receiveEvent();
  //現在の状態とイベントから処理を実行し遷移する状態を返す
  state = handleEvent(state, event);
}
