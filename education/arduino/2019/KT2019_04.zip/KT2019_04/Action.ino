//Actionタブ

/**
   設定時間を１分増加する
*/
void addOneMinute() {
  time += 60000L; //設定時間を60000ミリ秒加算する
}

/**
   カウントダウンを開始する
*/
void startTimer() {
  startTime = millis(); //カウントダウン開始時間に現在の時間を代入
  remainTime = time;    //残り時間に設定時間を代入
}

/**
   カウントダウンを停止する
*/
void stopTimer() {
  time = remainTime;  //設定時間に残り時間を代入する
}

/**
   タイマーを更新する
*/
void updateTimer() {
  remainTime = time + startTime - millis(); //残り時間を更新する
}

/**
   アラームを鳴らす
*/
void startAlarm() {
  startBuzzer();  //ブザーを鳴らす
  lightOn();      //LEDを点灯する
}

/**
   アラームを止める
*/
void stopAlarm() {
  stopBuzzer(); //ブザーを止める
  lightOff();   //LEDを消灯する
}

/**
   時間と状態を表示する

   @param ms  時間（ミリ秒）
   @param s   状態
*/
void displayTimer(long ms, enum State s) {

  int minute = int((ms / 1000L) / 60L); //分を求める
  int second = int((ms / 1000L) % 60L); //秒を求める
  int msec   = int(ms % 1000L);       //ミリ秒を求める

  //表示する時間（文字列）を作成する
  String str1 = "";
  if (minute >= 0 && minute < 10) { //分が1桁の場合
    str1 += String("0");          //10の位に0を追加
  }
  str1 += String(minute);         //分を文字列str1に連結する

  str1 += String(":");            //:を文字列str1に連結する

  if (second >= 0 && second < 10) { //秒が1桁の場合
    str1 += String("0");          //10の位に0を追加
  }
  str1 += String(second);         //秒を文字列str1に連結する

  str1 += String(".");            //秒とミリ秒の間に .を追加

  if (msec >= 0 && msec < 100) {  //ミリ秒が2桁以下の場合
    str1 += String("0");          //100の位に0を追加
  }
  if (msec >= 0 && msec < 10) {   //ミリ秒が1桁以下の場合
    str1 += String("0");          //10の位に0を追加
  }
  str1 += String(msec);           //ミリ秒を文字列str1に連結する

  //表示する状態（文字列）を作成する
  String str2 = "";
  //状態を文字列str2に追加する
  if (s == STATE_INIT) {
    str2 = String("STATE_INIT");
  } else if (s == STATE_SETTING) {
    str2 = String("STATE_SETTING");
  } else if (s == STATE_COUNTDOWN) {
    str2 = String("STATE_COUNTDOWN");
  } else if (s == STATE_PAUSE) {
    str2 = String("STATE_PAUSE");
  } else if (s == STATE_ALARM) {
    str2 = String("STATE_ALARM");
  } else {
    str2 = String("UNKNOWN");
  }

  //計測時間を1行目に表示、状態を2行目に表示
  displayString(str1, str2);

}
