//Stateタブ

/**
   イベントが起きた時にそれを処理する関数

   @return  {@code STATE_INIT}      初期状態
   @return  {@code STATE_SETTING}   時間設定中
   @return  {@code STATE_COUNTDOWN} カウントダウン中
   @return  {@code STATE_PAUSE}     一時停止中
   @return  {@code STATE_ALARM}     アラーム鳴動中
   @param s 現在の状態
   @param e 発生したイベント
*/
enum State handleEvent(enum State s, enum Event e) {

  enum State ret = s;

  switch (s) {
    case STATE_INIT:  //初期状態

      //必ず実行する処理
      time = 0L;            //設定時間を初期化する
      startTime = 0L;       //カウントダウン開始時間を初期化する
      remainTime = 0L;      //残り時間を初期化する
      displayTimer(time, s);  //設定時間を表示する

      //イベント発生時の処理
      if (e == EVENT_PUSH_MINUTE_BUTTON) {  //分ボタンを押した場合
        addOneMinute();       //設定時間を1分増加
        ret = STATE_SETTING;  //時間設定中に遷移
      } else if (e == EVENT_PUSH_START_STOP_BUTTON) { //StartStopボタンを押した場合
        //無視
      } else if (e == EVENT_TIME_IS_UP) { //残り時間が0になる場合
        //無視
      }
      break;

    case STATE_SETTING: //時間設定中

      //必ず実行する処理
      displayTimer(time, s);  //設定時間を初期化する

      //イベント発生時の処理
      if (e == EVENT_PUSH_MINUTE_BUTTON) {  //分ボタンを押した場合
        addOneMinute();       //設定時間を1分増加
        ret = STATE_SETTING;  //時間設定中に遷移
      } else if (e == EVENT_PUSH_START_STOP_BUTTON) { //StartStopボタンを押した場合
        startTimer();           //カウントダウンを開始する
        ret = STATE_COUNTDOWN;  //カウントダウン中に遷移する
      } else if (e == EVENT_TIME_IS_UP) { //残り時間が0になる場合
        //無視
      }
      break;

    case STATE_COUNTDOWN: //カウントダウン中

      //必ず実行する処理
      updateTimer();                //タイマーを更新する
      displayTimer(remainTime, s);  //残り時間を表示する

      //イベント発生時の処理
      if (e == EVENT_PUSH_MINUTE_BUTTON) {  //分ボタンを押した場合
        //無視
      } else if (e == EVENT_PUSH_START_STOP_BUTTON) {  //StartStopボタンを押した場合
        stopTimer();        //カウントダウンを停止する
        ret = STATE_PAUSE;  //一時停止中に遷移する
      } else if (e == EVENT_TIME_IS_UP) { //残り時間が0になる場合
        startAlarm();       //アラームを開始する
        ret = STATE_ALARM;  //アラーム鳴動中に遷移する
      }
      break;

    case STATE_PAUSE: //一時停止中

      //必ず実行する処理
      displayTimer(time, s);  //設定時間を表示する

      //イベント発生時の処理
      if (e == EVENT_PUSH_MINUTE_BUTTON) {  //分ボタンを押した場合
        addOneMinute();       //設定時間を1分増加
        ret = STATE_SETTING;  //時間設定中に遷移する
      } else if (e == EVENT_PUSH_START_STOP_BUTTON) { //StartStopボタンを押した場合
        startTimer();         //カウントダウンを開始する
        ret = STATE_COUNTDOWN;//カウントダウン中に遷移する
      } else if (e == EVENT_TIME_IS_UP) { //残り時間が0になる場合
        //不可
      }
      break;

    case STATE_ALARM: //アラーム鳴動中

      //必ず実行する処理
      time = 0L;            //設定時間を初期化する
      startTime = 0L;       //カウントダウン開始時間を初期化する
      remainTime = 0L;      //残り時間を初期化する
      displayTimer(time, s);//設定時間を表示する
      startAlarm();         //アラームを開始する

      //イベント発生時の処理
      if (e == EVENT_PUSH_MINUTE_BUTTON) {  //分ボタンを押した場合
        //無視
      } else if (e == EVENT_PUSH_START_STOP_BUTTON) { //StartStopボタンを押した場合
        stopAlarm();      //アラームを停止する
        ret = STATE_INIT; //初期状態に遷移する
      } else if (e == EVENT_TIME_IS_UP) { //残り時間が0になる場合
        //無視
      }
      break;

    default:  //それ以外
      ret = s;
      break;
  }
  return ret;
}
