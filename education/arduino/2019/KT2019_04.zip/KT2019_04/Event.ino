//Eventタブ

/**
   分ボタンを押したかどうか

   @return  {@code  true}   分ボタンを押した
   @return  {@code  false}  分ボタンを押していない
*/
boolean MinuteButtonIsPressed() {
  static boolean val_old = false;     //1回前の測定値を入れる変数
  boolean val = SWIsPressed(SW2Pin);  //現在の測定値
  boolean ret = false;                //戻り値を入れる変数

  if (val_old == false && val == true) { //分ボタンをOFFからONに変わったとき
    ret = true;
  } else {
    ret = false;
  }
  val_old = val;  //測定値更新
  return ret;
}

/**
   StartStopボタンを押したかどうか

   @return  {@code  true}   StartStopボタンを押した
   @return  {@code  false}  StartStopボタンを押していない
*/
boolean StartStopButtonIsPressed() {
  static boolean val_old = false;     //1回前の測定値を入れる変数
  boolean val = SWIsPressed(SW1Pin);  //現在の測定値
  boolean ret = false;                //戻り値を入れる変数

  if (val_old == false && val == true) { //StartStopボタンをOFFからONに変わったとき
    ret = true;
  } else {
    ret = false;
  }
  val_old = val;  //測定値更新
  return ret;
}

/**
   残り時間が0になったかどうか

   @return  {@code  true}   残り時間が0以下
   @return  {@code  false}  残り時間が0より大きい
*/
boolean TimeIsUp() {
  if (remainTime <= 0L) { //残り時間が0以下になる場合
    return true;
  } else {
    return false;
  }
}

/**
   イベント発生を確認する

   @return  {@code  EVENT_PUSH_MINUTE_BUTTON} 分ボタンを押すイベント
   @return  {@code  EVENT_PUSH_START_STOP_BUTTON} StartStopボタンを押すイベント
   @return  {@code  EVENT_TIME_IS_UP} 残り時間が0になるイベント
   @return  {@code  EVENT_NONE} イベントが発生していない
*/
enum Event receiveEvent() {
  if (MinuteButtonIsPressed()) {
    return EVENT_PUSH_MINUTE_BUTTON;
  } else if (StartStopButtonIsPressed()) {
    return EVENT_PUSH_START_STOP_BUTTON;
  } else if (TimeIsUp()) {
    return EVENT_TIME_IS_UP;
  } else {
    return EVENT_NONE;
  }
}
