//Deviceタブ
#include <LiquidCrystal.h>
LiquidCrystal lcd(5, 6, 7, 8, 9, 10, 11);
const int SW1Pin = 2;   //StartStopボタン
const int SW2Pin = 4;   //分ボタン
const int LEDPin = 13;  //LED
const int SPKPin = 3;   //ブザー

/**
   デバイスの初期設定を行う
*/
void setupDevice() {
  pinMode(SW1Pin, INPUT);   //SW1Pinを入力設定
  pinMode(SW2Pin, INPUT);   //SW2Pinを入力設定
  pinMode(LEDPin, OUTPUT);  //LEDPinを出力設定
  lcd.begin(16, 2);         //LCDの設定
  lcd.clear();              //画面消去
  Serial.begin(9600);       //シリアルモニタ開始
}

/**
   LCDに文字列を表示する

   @param str1  1行目に表示する文字列
   @param str2  2行目に表示する文字列
*/
void displayString(String str1, String str2) {
  lcd.clear();          //画面消去
  lcd.setCursor(0, 0);  //上段左端に移動
  lcd.print(str1);      //文字列str1を表示
  lcd.setCursor(0, 1);  //下段左端に移動
  lcd.print(str2);      //文字列str2を表示
}

/**
   スイッチを押したかどうか

   @return  {@code true}  スイッチを押した
   @return  {@code false} スイッチを押していない
*/
boolean SWIsPressed(int pin) {
  if (digitalRead(pin) == HIGH) { //pin番のスイッチが押された場合
    return true;                //trueを返す
  } else {                      //それ以外
    return false;               //falseを返す
  }
}

/**
   ブザーを鳴らす
*/
void startBuzzer() {
  tone(SPKPin, 880);  //トーン音を880Hzで鳴らす
}

/**
   ブザーを止める
*/
void stopBuzzer() {
  noTone(SPKPin);     //トーン音を止める
}

/**
   LEDを点灯する
*/
void lightOn() {
  digitalWrite(LEDPin, HIGH); //LEDを点灯する
}

/**
   LEDを消灯する
*/
void lightOff() {
  digitalWrite(LEDPin, LOW);  //LEDを消灯する
}
