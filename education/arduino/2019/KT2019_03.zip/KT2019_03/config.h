enum State {
  STATE_INIT,     //初期状態
  STATE_SETTING,  //設定中
  STATE_COUNTDOWN,//カウントダウン中
  STATE_PAUSE,    //一時停止中
  STATE_ALARM     //アラーム鳴動中
} state;

enum Event {
  EVENT_NONE,                   //イベントが発生しない
  EVENT_PUSH_MINUTE_BUTTON,     //分ボタンを押す
  EVENT_PUSH_START_STOP_BUTTON, //StartStopボタンを押す
  EVENT_TIME_IS_UP              //残り時間が0になる
} event;
