//Stateタブ
enum State handleEvent(enum State s, enum Event e) {

  enum State ret = s;

  switch (s) {
    case STATE_INIT:                        //初期状態
      displayTimer(time, s);                //設定時間と状態を表示する
      if (e == EVENT_PUSH_MINUTE_BUTTON) {  //分ボタンを押したら
        addOneMinute();                     //設定時間を1分増加する
        ret = STATE_SETTING;                //時間設定中に遷移する
      }
      break;

    case STATE_SETTING:                     //時間設定中
      displayTimer(time, s);                //設定時間と状態を表示する
      if (e == EVENT_PUSH_MINUTE_BUTTON) {  //分ボタンを押したら
        addOneMinute();                     //設定時間を1分増加する
        ret = STATE_SETTING;                //時間設定中に遷移する
      } else if (e == EVENT_PUSH_START_STOP_BUTTON) { //Start/Stopボタンを押したら
        startTimer();                       //カウントダウンを開始する
        ret = STATE_COUNTDOWN;              //カウントダウン中に遷移する
      }
      break;

    case STATE_COUNTDOWN:                   //カウントダウン中
      updateTimer();                        //残り時間を更新する
      displayTimer(remainTime, s);          //残り時間と状態を表示する
      if (e == EVENT_PUSH_START_STOP_BUTTON) {//Start/Stopボタンを押したら
        stopTimer();                        //カウントダウンを停止する
        ret = STATE_PAUSE;                  //一時停止中に遷移する
      } else if (e == EVENT_TIME_IS_UP) {   //残り時間が0になったら
        startAlarm();                       //アラームを鳴らす
        ret = STATE_ALARM;                  //アラーム鳴動中に遷移
      }
      break;

    case STATE_PAUSE:                       //一時停止中
      displayTimer(time, s);                //設定時間と状態を表示する
      if (e == EVENT_PUSH_MINUTE_BUTTON) {  //分ボタンを押したら
        addOneMinute();                     //設定時間を1分増加する
        ret = STATE_SETTING;                //時間設定中に遷移する
      } else if (e == EVENT_PUSH_START_STOP_BUTTON) { //Start/Stopボタンを押したら
        startTimer();                       //カウントダウンを開始する
        ret = STATE_COUNTDOWN;              //カウントダウン中に遷移する
      }
      break;

    case STATE_ALARM:                       //アラーム鳴動中
      time = 0L;                            //設定時間を0にする
      startTime = 0L;                       //開始時間を0にする
      remainTime = 0L;                      //残り時間を0にする
      displayTimer(time, s);                //設定時間と状態を表示する
      startAlarm();                         //アラームを鳴らす
      if (e == EVENT_PUSH_START_STOP_BUTTON) {  //Start/Stopボタンを押したら
        stopAlarm();                        //アラームを止める
        ret = STATE_INIT;                   //初期状態に遷移
      }
      break;

    default:    //それ以外
      ret = s;  //現在の状態をそのまま返す
      break;
  }
  return ret;   //次の状態を返す
}
