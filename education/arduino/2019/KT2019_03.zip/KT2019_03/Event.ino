//Eventタブ
boolean MinuteButtonIsPressed(){      //分ボタンを押したか
  static boolean val_old = false;     //1回前の測定値を入れる変数
  boolean val = SWIsPressed(SW2Pin);  //現在の測定値
  boolean ret = false;                //戻り値を入れる変数
  
  if(val_old == false && val == true){  //修正
    ret = true;
  } else {
    ret = false;
  }
  val_old = val;  //測定値更新
  return ret;
}

boolean StartStopButtonIsPressed(){  //StartStopボタンを押したか
  static boolean val_old = false;     //1回前の測定値を入れる変数
  boolean val = SWIsPressed(SW1Pin);  //現在の測定値
  boolean ret = false;                //戻り値を入れる変数
  
  if(val_old == false && val == true){  //修正
    ret = true;
  } else {
    ret = false;
  }
  val_old = val;  //測定値更新
  return ret;
}

boolean TimeIsUp(){                  //計測時間が0になったか
  if(remainTime <= 0L){
    return true;
  } else {
    return false;
  }  
}

enum Event receiveEvent(){
  if(MinuteButtonIsPressed()){
    return EVENT_PUSH_MINUTE_BUTTON;
  } else if(StartStopButtonIsPressed()){
    return EVENT_PUSH_START_STOP_BUTTON;
  } else if(TimeIsUp()){
    return EVENT_TIME_IS_UP;
  } else {
    return EVENT_NONE;
  }
}
