#include "config.h"

long time;        //設定時間
long startTime;   //カウントダウン開始時間
long remainTime;  //残り時間

void setup() {
  setupDevice();        //デバイスの初期設定を実行
  time = 0L;            //設定時間を0に初期化
  startTime = 0L;       //開始時間を0に初期化
  remainTime = 0L;      //残り時間を0に初期化
  state = STATE_INIT;   //状態変数を初期状態に設定する
  event = EVENT_NONE;   //イベント変数を"発生していない"に設定する
}

void loop() {
  //現在発生しているイベントを返す
  event = receiveEvent();
  //現在の状態とイベントから処理を実行し遷移する状態を返す
  state = handleEvent(state, event);
}
